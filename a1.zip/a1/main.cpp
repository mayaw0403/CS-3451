//#####################################################################
// Main
// CS3451 Computer Graphics Starter Code
// Contact: Bo Zhu (bo.zhu@gatech.edu)
//#####################################################################
#include <iostream>
#include <random>

#include "OpenGLMesh.h"
#include "OpenGLCommon.h"
#include "OpenGLWindow.h"
#include "OpenGLViewer.h"

/////////////////////////////////////////////////////////////////////
//// TODO: put your name in the string               
/////////////////////////////////////////////////////////////////////

const std::string author="Maya Williams";

/////////////////////////////////////////////////////////////////////
//// These are helper functions we created to generate circles and triangles by testing whether a point is inside the shape or not.
//// They can be used in the paintGrid function as "if the pixel is inside, draw some color; else skip."
//// You may create your own functions to draw your own shapes

//// The paintGrid function is implemented as a GLSL fragment shader. 
//// The GLSL grammar is C-style, and if you are curious about its full picture (which we will start to learn the details in Week 3), 
//// you may find more information on https://www.khronos.org/files/opengl43-quick-reference-card.pdf (Page 6 - 7 would probably be helpful!)
//// You don't need advanced GLSL features for this assignment (reading the starter code should be enough).
//// You can also test it (copy the whole string) in Shadertoy: https://www.shadertoy.com/new    
/////////////////////////////////////////////////////////////////////

const std::string draw_pixels=To_String(
const float M_PI=3.1415926535; 

// The side length of the minimum unit (or the new "pixels")
const float PIXEL_SIZE=10.; 

// To check if a point is inside a circle
bool inCircle(vec2 p, vec2 center, float radius) {
	vec2 to_center=p - center;
	if (dot(to_center, to_center) < radius * radius) {
		return true;
	}
	return false;
}

// To check if a point is inside a triangle
bool inTriangle(vec2 p, vec2 p1, vec2 p2, vec2 p3) {
	if (dot(cross(vec3(p2 - p1, 0), vec3(p - p1, 0)), cross(vec3(p2 - p1, 0), vec3(p3 - p1, 0))) >= 0. &&
		dot(cross(vec3(p3 - p2, 0), vec3(p - p2, 0)), cross(vec3(p3 - p2, 0), vec3(p1 - p2, 0))) >= 0. &&
		dot(cross(vec3(p1 - p3, 0), vec3(p - p3, 0)), cross(vec3(p1 - p3, 0), vec3(p2 - p3, 0))) >= 0.) {
		return true;
	}
	return false;
}

// To convert from Polar Coordinates to Cartesian coordinates
vec2 polar2cart(float angle, float length) {
	return vec2(cos(angle) * length, sin(angle) * length);
}

/////////////////////////////////////////////////////////////////////////
// Feel free to add more functions if needed!                          
/////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////
// TODO: replace the code below with your own code                 //
// Useful variables:											   //
// iTime: the passed seconds from the start of the program         //
// iResolution: the size of the window (default: 1280*960)         //
/////////////////////////////////////////////////////////////////////

// Return the rgba color of the grid at position (x, y) 
vec4 paintGrid(float x, float y) {
    vec2 center = vec2(iResolution / PIXEL_SIZE / 2.); // window center

    // Sky color set to C94E4B
	vec3 skyColor = vec3(201, 78, 75) / 255.0;

	// Background color set to EA6252
	vec3 backgroundColor = vec3(234, 98, 82) / 255.0;

    // The height where the sky ends (just below the clouds)
    float skyHeight = 1.6 * center.y + 0.07 * center.x;

    // Check if the pixel is below the sky
    bool belowSky = y > skyHeight;

    // Define vertices for three pyramids of the same size
	//Pyramid 1
    vec2 p1 = vec2(0.4 * center.x, 0.9 * center.y);
    vec2 p2 = vec2(0.2 * center.x, 0.5 * center.y);
    vec2 p3 = vec2(0.6 * center.x, 0.5 * center.y);

	//Pyramid 2
    vec2 p4 = vec2(1.0 * center.x, 0.9 * center.y); // Moved more to the right
    vec2 p5 = vec2(0.8 * center.x, 0.5 * center.y); // Moved more to the right
    vec2 p6 = vec2(1.2 * center.x, 0.5 * center.y); // Moved more to the right

	//Pyramid 3
    vec2 p7 = vec2(1.6 * center.x, 0.9 * center.y); // Moved far over to the right
    vec2 p8 = vec2(1.4 * center.x, 0.5 * center.y); // Moved far over to the right
    vec2 p9 = vec2(1.8 * center.x, 0.5 * center.y); // Moved far over to the right

    // Sun position (further to the right and up)
    vec2 sunPosition = vec2(2.6 * center.x, 2.6 * center.y);
    float sunRadius = 1.2 * center.x;

    // Check if the pixel is inside any of the three pyramids or the sun
    bool inTriangle1 = inTriangle(vec2(x, y), p1, p2, p3);
    bool inTriangle2 = inTriangle(vec2(x, y), p4, p5, p6);
    bool inTriangle3 = inTriangle(vec2(x, y), p7, p8, p9);
    bool inSun = length(vec2(x, y) - sunPosition) <= sunRadius;

    // Calculate shading based on the distance from the top vertex
    float shading1 = clamp(1.0 - abs((x - p1.x) / (p2.x - p1.x)), 0.0, 1.0);
    float shading2 = clamp(1.0 - abs((x - p4.x) / (p5.x - p4.x)), 0.0, 1.0);
    float shading3 = clamp(1.0 - abs((x - p7.x) / (p8.x - p7.x)), 0.0, 1.0);

    // Circular Clouds
	//Cloud 1
    vec2 cloud1Center = vec2(0.1 * center.x, 1.8 * center.y);
    vec2 cloud2Center = vec2(0.2 * center.x, 1.8 * center.y);
    vec2 cloud3Center = vec2(0.3 * center.x, 1.8 * center.y);

	//Cloud 2
    vec2 cloud4Center = vec2(0.6 * center.x, 1.8 * center.y);
    vec2 cloud5Center = vec2(0.7 * center.x, 1.8 * center.y);
    vec2 cloud6Center = vec2(0.8 * center.x, 1.8 * center.y);

	//Cloud 3
    vec2 cloud7Center = vec2(1.1 * center.x, 1.8 * center.y);
    vec2 cloud8Center = vec2(1.2 * center.x, 1.8 * center.y);
    vec2 cloud9Center = vec2(1.3 * center.x, 1.8 * center.y);

    float cloudRadius = 0.07 * center.x; // Larger circles

    bool inCloud1 = length(vec2(x, y) - cloud1Center) <= cloudRadius;
    bool inCloud2 = length(vec2(x, y) - cloud2Center) <= cloudRadius;
    bool inCloud3 = length(vec2(x, y) - cloud3Center) <= cloudRadius;

    bool inCloud4 = length(vec2(x, y) - cloud4Center) <= cloudRadius;
    bool inCloud5 = length(vec2(x, y) - cloud5Center) <= cloudRadius;
    bool inCloud6 = length(vec2(x, y) - cloud6Center) <= cloudRadius;

    bool inCloud7 = length(vec2(x, y) - cloud7Center) <= cloudRadius;
    bool inCloud8 = length(vec2(x, y) - cloud8Center) <= cloudRadius;
    bool inCloud9 = length(vec2(x, y) - cloud9Center) <= cloudRadius;

    vec3 cloudColor = vec3(0.95, 0.95, 0.95); // light gray white cloud color

	// The height where the brownish sand starts
    float sandHeight = 0.45 * center.y;

    // Check if the pixel is below the brownish sand
    bool belowSand = y < sandHeight;

    // Brownish sand color
    vec3 sandColor = vec3(139, 69, 19) / 255.; // Brown color for sand

	// Sine wave ripple effect parameters
	float rippleFrequency = 8.0;
	float rippleAmplitude = 0.05;

	// Calculated the ripple placement based on the distance from the sand center
	vec2 sandCenter = vec2(center.x, sandHeight);
	vec2 toSandCenter = vec2(x, y) - sandCenter;
	float distanceToSandCenter = length(toSandCenter);
	float ripplePlacement = rippleAmplitude * sin(rippleFrequency * distanceToSandCenter);

	// Modify sandColor based on the sine wave ripple effect
	vec3 modifiedSandColor = sandColor + vec3(ripplePlacement, ripplePlacement, 0.0);

	// Return the color with added shading for all pyramids, sun, clouds, or background color
    if (inCloud1 || inCloud2 || inCloud3 || inCloud4 || inCloud5 || inCloud6 || inCloud7 || inCloud8 || inCloud9) {
        return vec4(cloudColor, 1.0);
    } else if (inTriangle1) {
        vec3 triangleColor = vec3(255, 255, 0) / 255.; // Tanish color for pyramid 1
        return vec4(mix(backgroundColor, triangleColor * shading1, 0.5), 1.0);
    } else if (inTriangle2) {
        vec3 triangleColor = vec3(255, 255, 0) / 255.; // Tanish color for pyramid 2
        return vec4(mix(backgroundColor, triangleColor * shading2, 0.5), 1.0);
    } else if (inTriangle3) {
        vec3 triangleColor = vec3(255, 255, 0) / 255.; // Tanish color for pyramid 3
        return vec4(mix(backgroundColor, triangleColor * shading3, 0.5), 1.0);
    } else if (inSun) {
        // Sun color (orange)
        return vec4(vec3(255, 165, 0) / 255., 1.0);
    } else if (belowSky) {
        // Check if the pixel is below the sky
        return vec4(skyColor, 1.0);
    } else if (belowSand) {
        // Check if the pixel is below the brownish sand
        return vec4(modifiedSandColor, 1.0);
    } else {
		// Return sunset-ish orange background color
		return vec4(backgroundColor, 1.0);
	}
}
/////////////////////////////////////////////////////////////////////////////////////////
// The function called in the fragment shader
void mainImage(out vec4 fragColor, in vec2 fragCoord)
{
	// To divide the screen into the grids for painting!
	fragColor=paintGrid(floor(fragCoord.x / PIXEL_SIZE), floor(fragCoord.y / PIXEL_SIZE));
}

);

class ScreenDriver : public OpenGLViewer
{
	OpenGLScreenCover* screen_cover=nullptr;
	clock_t startTime=clock();

public:
	virtual void Initialize()
	{
		OpenGLViewer::Initialize();
	}

	//// Initialize the screen covering mesh and shaders
	virtual void Initialize_Data()
	{
		OpenGLShaderLibrary::Instance()->Create_Screen_Shader(draw_pixels, "shaderToy");
		screen_cover=Add_Interactive_Object<OpenGLScreenCover>();
		Set_Polygon_Mode(screen_cover, PolygonMode::Fill);
		Uniform_Update();

		screen_cover->Set_Data_Refreshed();
		screen_cover->Initialize();
		screen_cover->Add_Shader_Program(OpenGLShaderLibrary::Get_Shader("shaderToy"));
	}

	//// Update the uniformed variables used in shader
	void Uniform_Update()
	{
		screen_cover->setResolution((float)Win_Width(), (float)Win_Height());
		screen_cover->setTime(GLfloat(clock() - startTime) / CLOCKS_PER_SEC);
	}

	//// Go to next frame 
	virtual void Toggle_Next_Frame()
	{
		Uniform_Update();
		OpenGLViewer::Toggle_Next_Frame();
	}

	////Keyboard interaction
	virtual void Initialize_Common_Callback_Keys()
	{
		OpenGLViewer::Initialize_Common_Callback_Keys();
	}

	virtual void Run()
	{
		OpenGLViewer::Run();
	}
};

int main(int argc,char* argv[])
{
	if(author==""){std::cerr<<"***** The author name is not specified. Please put your name in the author string first. *****"<<std::endl;return 0;}
	else std::cout<<"Assignment 1 demo by "<<author<<" started"<<std::endl;
	
	ScreenDriver driver;
	driver.Initialize();
	driver.Run();	
}
